package com.fatec.comercio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComercioApplicationTests {

	@Test
	void contextLoads() {
	}

}
