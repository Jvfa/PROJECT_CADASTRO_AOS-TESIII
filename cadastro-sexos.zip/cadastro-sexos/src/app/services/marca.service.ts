import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface para o modelo Marca
export interface Marca {
  codmarca?: number;
  nomemarca: string;
}

@Injectable({ providedIn: 'root' })
export class MarcaService {
  // Endpoint da API para marcas
  private apiUrl = 'http://localhost:8090/marcas';

  constructor(private http: HttpClient) {}

  // Retorna todas as marcas
  getMarcas(): Observable<Marca[]> {
    return this.http.get<Marca[]>(this.apiUrl);
  }

  // Retorna uma marca específica pelo ID
  getMarca(id: number): Observable<Marca> {
    return this.http.get<Marca>(`${this.apiUrl}/${id}`);
  }

  // Cria uma nova marca
  createMarca(marca: Marca): Observable<Marca> {
    return this.http.post<Marca>(this.apiUrl, marca);
  }

  // Atualiza uma marca existente
  updateMarca(id: number, marca: Marca): Observable<Marca> {
    return this.http.put<Marca>(`${this.apiUrl}/${id}`, marca);
  }

  // Exclui uma marca
  deleteMarca(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}