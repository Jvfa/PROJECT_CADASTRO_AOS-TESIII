import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface para o modelo Tipo
export interface Tipo {
  codtipo?: number;
  nometipo: string;
}

@Injectable({ providedIn: 'root' })
export class TipoService {
  // Endpoint da API para tipos
  private apiUrl = 'http://localhost:8090/tipos';

  constructor(private http: HttpClient) {}

  // Retorna todos os tipos
  getTipos(): Observable<Tipo[]> {
    return this.http.get<Tipo[]>(this.apiUrl);
  }

  // Retorna um tipo específico pelo ID
  getTipo(id: number): Observable<Tipo> {
    return this.http.get<Tipo>(`${this.apiUrl}/${id}`);
  }

  // Cria um novo tipo
  createTipo(tipo: Tipo): Observable<Tipo> {
    return this.http.post<Tipo>(this.apiUrl, tipo);
  }

  // Atualiza um tipo existente
  updateTipo(id: number, tipo: Tipo): Observable<Tipo> {
    return this.http.put<Tipo>(`${this.apiUrl}/${id}`, tipo);
  }

  // Exclui um tipo
  deleteTipo(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}