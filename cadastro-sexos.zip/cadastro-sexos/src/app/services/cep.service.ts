import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface para o modelo Cep
export interface Cep {
  codcep?: number;
  numerocep: string;
}

@Injectable({ providedIn: 'root' })
export class CepService {
  // Endpoint da API para ceps
  private apiUrl = 'http://localhost:8090/ceps';

  constructor(private http: HttpClient) {}

  // Retorna todos os ceps
  getCeps(): Observable<Cep[]> {
    return this.http.get<Cep[]>(this.apiUrl);
  }

  // Retorna um cep específico pelo ID
  getCep(id: number): Observable<Cep> {
    return this.http.get<Cep>(`${this.apiUrl}/${id}`);
  }

  // Cria um novo cep
  createCep(cep: Cep): Observable<Cep> {
    return this.http.post<Cep>(this.apiUrl, cep);
  }

  // Atualiza um cep existente
  updateCep(id: number, cep: Cep): Observable<Cep> {
    return this.http.put<Cep>(`${this.apiUrl}/${id}`, cep);
  }

  // Exclui um cep
  deleteCep(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}