import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface para o modelo Rua
export interface Rua {
  codrua?: number;
  nomerua: string;
}

@Injectable({ providedIn: 'root' })
export class RuaService {
  // Endpoint da API para ruas
  private apiUrl = 'http://localhost:8090/ruas';

  constructor(private http: HttpClient) {}

  // Retorna todas as ruas
  getRuas(): Observable<Rua[]> {
    return this.http.get<Rua[]>(this.apiUrl);
  }

  // Retorna uma rua específica pelo ID
  getRua(id: number): Observable<Rua> {
    return this.http.get<Rua>(`${this.apiUrl}/${id}`);
  }

  // Cria uma nova rua
  createRua(rua: Rua): Observable<Rua> {
    return this.http.post<Rua>(this.apiUrl, rua);
  }

  // Atualiza uma rua existente
  updateRua(id: number, rua: Rua): Observable<Rua> {
    return this.http.put<Rua>(`${this.apiUrl}/${id}`, rua);
  }

  // Exclui uma rua
  deleteRua(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}