import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface para o modelo Bairro
export interface Bairro {
  codbairro?: number;
  nomebairro: string;
}

@Injectable({ providedIn: 'root' })
export class BairroService {
  // Endpoint da API para bairros
  private apiUrl = 'http://localhost:8090/bairros';

  constructor(private http: HttpClient) {}

  // Retorna todos os bairros
  getBairros(): Observable<Bairro[]> {
    return this.http.get<Bairro[]>(this.apiUrl);
  }

  // Retorna um bairro específico pelo ID
  getBairro(id: number): Observable<Bairro> {
    return this.http.get<Bairro>(`${this.apiUrl}/${id}`);
  }

  // Cria um novo bairro
  createBairro(bairro: Bairro): Observable<Bairro> {
    return this.http.post<Bairro>(this.apiUrl, bairro);
  }

  // Atualiza um bairro existente
  updateBairro(id: number, bairro: Bairro): Observable<Bairro> {
    return this.http.put<Bairro>(`${this.apiUrl}/${id}`, bairro);
  }

  // Exclui um bairro
  deleteBairro(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
