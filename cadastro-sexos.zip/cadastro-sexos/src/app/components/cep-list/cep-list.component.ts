import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CepService, Cep } from '../../services/cep.service';

@Component({
  selector: 'app-cep-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './cep-list.component.html',
  styleUrls: ['./cep-list.component.scss'],
})
export class CepListComponent implements OnInit {
  ceps: Cep[] = [];

  constructor(private cepService: CepService) {}

  ngOnInit(): void {
    this.loadCeps();
  }

  loadCeps(): void {
    this.cepService.getCeps().subscribe(
      (data) => (this.ceps = data),
      (error) => console.error('Erro ao carregar CEPs', error)
    );
  }

  deleteCep(id: number): void {
    if (confirm('Tem certeza que deseja excluir este CEP?')) {
      this.cepService.deleteCep(id).subscribe(
        () => this.loadCeps(),
        (error) => console.error('Erro ao excluir CEP', error)
      );
    }
  }
}