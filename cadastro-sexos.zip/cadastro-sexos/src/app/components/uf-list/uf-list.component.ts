import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
// Importações atualizadas para o serviço e a interface de UF
import { UfService, Uf } from '../../services/uf.service';

@Component({
  // Seletor e caminhos de arquivo atualizados
  selector: 'app-uf-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './uf-list.component.html',
  styleUrls: ['./uf-list.component.scss'],
})
// Nome da classe atualizado
export class UfListComponent implements OnInit {
  // Array para armazenar a lista de UFs
  ufs: Uf[] = [];

  constructor(
    // Serviço injetado atualizado para UfService
    private ufService: UfService
  ) {}

  ngOnInit(): void {
    this.loadUfs();
  }

  // Método para carregar a lista de UFs
  loadUfs(): void {
    this.ufService.getUfs().subscribe(
      (data) => (this.ufs = data),
      (error) => console.error('Erro ao carregar UFs', error)
    );
  }

  // Método para excluir uma UF
  deleteUf(id: number): void {
    if (confirm('Tem certeza que deseja excluir esta UF?')) {
      this.ufService.deleteUf(id).subscribe(
        // Recarrega a lista após a exclusão
        () => this.loadUfs(),
        (error) => console.error('Erro ao excluir UF', error)
      );
    }
  }
}
