import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
// Importações atualizadas para o serviço e a interface de UF
import { UfService, Uf } from '../../services/uf.service';

@Component({
  // Seletor e caminhos de arquivo atualizados
  selector: 'app-uf-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './uf-form.component.html',
  styleUrls: ['./uf-form.component.scss'],
})
// Nome da classe atualizado
export class UfFormComponent implements OnInit {
  // Objeto 'uf' com as propriedades nomeuf e sigla
  uf: Uf = { nomeuf: '', sigla: '' };
  isEdit = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    // Serviço injetado atualizado para UfService
    private ufService: UfService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      // Chamada ao serviço para buscar uma UF específica
      this.ufService.getUf(+id).subscribe(
        (data) => (this.uf = data),
        (error) => console.error('Erro ao carregar UF', error)
      );
    }
  }

  onSubmit(): void {
    if (this.isEdit) {
      // Lógica para ATUALIZAR a UF
      this.ufService.updateUf(this.uf.coduf!, this.uf).subscribe(
        // Navega para a lista de UFs após o sucesso
        () => this.router.navigate(['/ufs']),
        (error) => console.error('Erro ao atualizar UF', error)
      );
    } else {
      // Lógica para CRIAR a UF
      this.ufService.createUf(this.uf).subscribe(
        // Navega para a lista de UFs após o sucesso
        () => this.router.navigate(['/ufs']),
        (error) => console.error('Erro ao criar UF', error)
      );
    }
  }
}
