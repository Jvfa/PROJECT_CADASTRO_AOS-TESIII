import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CepService, Cep } from '../../services/cep.service';

@Component({
  selector: 'app-cep-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './cep-form.component.html',
  styleUrls: ['./cep-form.component.scss'],
})
export class CepFormComponent implements OnInit {
  cep: Cep = { numerocep: '' };
  isEdit = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cepService: CepService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.cepService.getCep(+id).subscribe(
        (data) => (this.cep = data),
        (error) => console.error('Erro ao carregar CEP', error)
      );
    }
  }

  onSubmit(): void {
    if (this.isEdit) {
      this.cepService.updateCep(this.cep.codcep!, this.cep).subscribe(
        () => this.router.navigate(['/ceps']),
        (error) => console.error('Erro ao atualizar CEP', error)
      );
    } else {
      this.cepService.createCep(this.cep).subscribe(
        () => this.router.navigate(['/ceps']),
        (error) => console.error('Erro ao criar CEP', error)
      );
    }
  }
}